# СЛОВО — Android Wordle

Готовый Android-проект игры «Слово». Приложение работает локально, без регистрации и специальных разрешений; статистика хранится на устройстве.

## Как собрать APK через GitHub на телефоне

1. Открой репозиторий `https://github.com/exorexic/slovo.apk`.
2. Нажми **Add file → Upload files**.
3. Распакуй архив проекта так, чтобы в корне репозитория находились `app/`, `build.gradle`, `settings.gradle`, `gradle.properties` и `.github/` (не загружай внешний каталог `slovo-apk` целиком как вложенную папку).
4. Нажми **Commit changes**.
5. Открой **Actions → Build Android APK**. Если сборка не стартовала автоматически, нажми **Run workflow**.
6. Открой последний запуск со зелёной галочкой, прокрути вниз до **Artifacts** и скачай `slovo-debug-apk`.
7. Распакуй скачанный ZIP и установи `app-debug.apk` на Android. При необходимости разреши установку приложений из этого источника.

## Сборка вручную

Требуются JDK 17, Android SDK и Gradle 8.9+:

```bash
gradle assembleDebug
```

APK будет создан в `app/build/outputs/apk/debug/app-debug.apk`.

- Android package: `ru.slovo.game`
- Min SDK: 23 (Android 6.0)
- Target SDK: 35
- Версия: 1.0

## Состав

- `app/src/main/java/ru/slovo/game/MainActivity.java` — Android-оболочка WebView
- `app/src/main/assets/index.html` — интерфейс игры
- `app/src/main/assets/words.json` — локальный словарь
- `.github/workflows/build-apk.yml` — автоматическая сборка APK через GitHub Actions
